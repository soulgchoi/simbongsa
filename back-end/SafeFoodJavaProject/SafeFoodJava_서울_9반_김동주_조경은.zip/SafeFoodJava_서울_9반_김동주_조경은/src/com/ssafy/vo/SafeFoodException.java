package com.ssafy.vo;

public class SafeFoodException extends RuntimeException {
	public SafeFoodException(String msg) {
		super(msg);
	}
}
