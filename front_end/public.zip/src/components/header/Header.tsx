import React, { ReactElement } from "react";

interface Props {}

export default function Header({}: Props): ReactElement {
  return (
    <div>
      <div></div>
    </div>
  );
}
