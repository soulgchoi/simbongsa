export { default as LocationContainer } from 'containers/usersetting/LocationContainer';
export { default as CategoryContainer } from 'containers/usersetting/CategoryContainer';
export { default as AgeContainer } from 'containers/usersetting/AgeContainer';
export { default as TimeContainer } from 'containers/usersetting/TimeContainer';