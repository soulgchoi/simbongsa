import React, {Component} from 'react'
// import PostForm from './PostForm';


// class Timeline extends Component{

// render(){
//     return (
//         <div>
//             <PostForm
//             />
//             <div>
//                 {this.props.displayPosts}
//             </div>
//         </div>
//     )
// }
// }
// export default Timeline;